import React,{useState} from 'react';
import {
  DetailsHeader,
  DetailsList,
  IColumn,
} from 'office-ui-fabric-react/lib/DetailsList';
import axios from 'axios';
import { Dropdown, DropdownMenuItemType, IDropdownOption, IDropdownStyles, initializeIcons, ITextFieldStyles, mergeStyles, TextField } from 'office-ui-fabric-react';

export interface IDetailsListGroupedLargeExample{
 key?:any,
 name?:any,
 sno?:any,
 leadId?:any,
 phoneNumber?:any,
 type?:any,
 createdOn?:any,
}
export interface IDetailsListBasicExampleState extends IDetailsListGroupedLargeExample{
    items?:IDetailsListGroupedLargeExample[];
} 

const DetailsLists=({items}:IDetailsListBasicExampleState)=> {
  initializeIcons();
  const warn = console.warn;
 function logWarning(...warnings:any ){
  let showWarning = true;
  warnings.forEach((warning:any) => {
    if     (warning.includes("UNSAFE_"))    showWarning = false;
    else if(warning.includes("SourceMap"))  showWarning = false;
    else if(warning.includes("DevTools"))   showWarning = false;
  });
  if(showWarning) warn(...warnings);
}


console.warn  = logWarning;
   const[item,setItem]=useState<any>([]);
   const[allitem,setAllItem]=useState<any>([]);
   const[search,searchItem]=useState<any>('');
   let _columns :IColumn[];
   let _allItems:IDetailsListGroupedLargeExample[];
   const options = [
    { key: '15', text: '15' },
    { key: '25', text: '25' },
    { key: '50', text: '50' },
    { key: '100', text: '100' },
   
  ];
  const textFieldStyles: Partial<ITextFieldStyles> = { root: { maxWidth: '300px' } };
  // Dropdown
  const[selectedKey,setselectedKey]=useState<any>("15");
  const [selectedText, setselectedText] = useState<any>("15")
   const [selectedItem, setSelectedItem] = useState<any>(); 
   const [startlength, setstartlength] = useState<any>('0'); 


   const dropdownStyles: Partial<IDropdownStyles> = {
    dropdown: { width: 60 },
  };
  debugger;
   React.useEffect(()=>{
    onLoad(startlength,selectedKey,'');
     
         },[])

         //Starting function
     function onLoad(start?:any,length?:any,search?:any){
          debugger;
          _allItems=[];
          const  url=`https://apiuat.actingoffice.com/Contacts?start=${start}&length=${length}&search=${search}`
          const headers={
              Authorization:`Bearer ${localStorage.getItem('token')}`
          }
          debugger
          axios 
          .get(url,{headers})
            .then((res)=>{
                debugger;
                console.log(res);
                if(res.data.status==true){
                  for (let i = 0; i < res.data.result.items.length; i++) {
                      _allItems.push({
                        key: i,
                        name: res.data.result.items[i].name,
                        sno:res.data.result.items[i].sno,
                        leadId:res.data.result.items[i].leadId,
                        phoneNumber:res.data.result.items[i].phoneNumber?.number,
                        type:res.data.result.items[i].type,
                        createdOn:res.data.result.items[i].createdOn,
                       
                      });
                      setItem(_allItems);
                      setAllItem(_allItems);
                      
                    
                }
              
          }
      })
         }
function onSearch(){
  debugger
if(search !=="" || search!==undefined){
  _allItems=[];
    const  url=`https://apiuat.actingoffice.com/Contacts?start=0&length=25&search=${search}`
    const headers={
        Authorization:`Bearer ${localStorage.getItem('token')}`
    }
    debugger
    axios 
    .get(url,{headers})
      .then((res)=>{
          debugger;
          console.log(res);
          if(res.data.status==true){
            for (let i = 0; i < res.data.result.items.length; i++) {
                _allItems.push({
                  key: i,
                  name: res.data.result.items[i].name,
                  sno:res.data.result.items[i].sno,
                  leadId:res.data.result.items[i].leadId,
                   phoneNumber:res.data.result.items[i].phoneNumber?.number,
                  type:res.data.result.items[i].type,
                  createdOn:res.data.result.items[i].createdOn,
                 
                });
                setItem(_allItems);
                
               
          }
        
    }
  
 
    
})
  }
  else{
    setItem(allitem);
  }
}

    function _onFilter (ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, text?: string)   {
        debugger;
      if(text==="" || text==undefined){
        setItem(allitem);
      }
      else {
        const updatedList =item.filter((itm:any) => {
          return (
            itm.name.toLowerCase().search((text).toLowerCase()) !== -1
          );
        });
          setItem(updatedList);
      }
     
       
     //This will trigger a re-render
        
      
    };
 
    
const exampleChildClass = mergeStyles({
    display: 'block',
    marginBottom: '10px',
  });
  
   _columns = [
    { key: 'col1', name: 'Name', fieldName: 'name', minWidth: 100, maxWidth: 200 },
    { key: 'col2', name: 'sno', fieldName: 'sno', minWidth: 100, maxWidth: 200 },
    { key: 'col3', name: 'leadId', fieldName: 'leadId', minWidth: 100, maxWidth: 200 },
    { key: 'col4', name: 'phoneNumber', fieldName: 'phoneNumber', minWidth: 100, maxWidth: 200 },
    { key: 'col5', name: 'type', fieldName: 'type', minWidth: 100, maxWidth: 200 },
    { key: 'col6', name: 'createdOn', fieldName: 'createdOn', minWidth: 100, maxWidth: 200 },
  ]
 
  const onItemChange = (event: React.FormEvent<HTMLDivElement>, option: any = {},index?: number) => {
    
    setSelectedItem(option.key);
    setselectedKey(option.key)
    
  };


    return (<>
        <TextField
          className={exampleChildClass}
          label="Filter by name:"
       
          styles={textFieldStyles}
          value={search} onChange={(e, v) => {
            searchItem(v || "");
          onLoad(startlength,selectedKey,search)            
          }}
        />
      <DetailsList

        items={item}
        columns={_columns}
        ariaLabelForSelectAllCheckbox="Toggle selection for all items"
        ariaLabelForSelectionColumn="Toggle selection"
        checkButtonAriaLabel="Row checkbox"
       
      />
        <Dropdown
      defaultSelectedKey={selectedKey}
        options={options}
        selectedKey={selectedItem ? selectedItem.key : undefined}
        onChange={(e,option: any = {})=>{
          onLoad(startlength,option.key,'');
        setselectedKey(option.key)} }
        styles={dropdownStyles}
      />
    
      </>
    );
    
  
}
export default  DetailsLists;