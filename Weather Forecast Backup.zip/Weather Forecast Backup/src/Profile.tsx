import React, { Profiler } from 'react';

const Profile=()=>{
return(
    <h1>hii</h1>
);
}
export default Profile;